import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,//for input filed 2 way
    AppComponent, // Import the standalone component here
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
