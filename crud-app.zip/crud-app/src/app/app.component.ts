import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-root',
  standalone: true,
  //imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  imports: [CommonModule,FormsModule] // Add FormsModule here

})
export class AppComponent {
  title = 'hello-app';
  
  name: string = '';
  email: string = '';
  age: number | null = null;
  editIndex:number | null= null;
  people: { name: string, email: string, age: number | null }[] = [];

  addData() {
    if (this.name && this.email && this.age !== null) {

      if (this.editIndex !== null) {
        this.people[this.editIndex] = { name: this.name, email: this.email, age: this.age };
        this.editIndex = null;
      } else {
        this.people.push({ name: this.name, email: this.email, age: this.age });
      }
      this.name = '';
      this.email = '';
      this.age = null;
    }
  }

 

  export() {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.people);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['info'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'info_data');
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], {type: EXCEL_TYPE});
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  editData(index: number) {
    const person = this.people[index];
    this.name = person.name;
    this.email = person.email;
    this.age = person.age;
    this.editIndex = index;
  }

  delete(index: number){

    this.people.splice(index,1);
    console.log(index);

   
    console.log(this.editIndex);
    if(this.editIndex !==index){
   console.log('hi');
      this.name='';
      this.email='';
      this.age=null;
      this.editIndex=null;

    }else{
      console.log('error')
    }
   

  }
}
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';